/**
 * @version 1.0
 * @author ujqgi;
 */


public class Input extends List {
    public static final String PLACEHOLDER_SPACE = " ";
    private static final String ADD_SONG_TO_PLAYLIST = "add";
    private static final String REMOVE_SONG_FROM_PLAYLIST = "remove";
    private static final String PLAY_SONG_FROM_PLAYLIST = "play";
    private static final String SKIP_SONG = "skip";
    private static final String PEEK_NEXT_SONG_FROM_PLAYLIST = "peek";
    private static final String LIST_CURRENT_PLAYLIST = "list";
    private static final String HISTORY_OF_THE_PLAYLIST = "history";
    public static final String QUIT_CURRENT_PLAYLIST = "quit";
    private static String firstWord;
    private static String Attributes;

    /**
     * @param Input from the scanner
     * @returns the String firstWord, which equals the command from the input (f.e. add)
     */
        public static String getCommand(String Input) {
            if (Input.contains(PLACEHOLDER_SPACE)) {
                String[] arr = Input.split(PLACEHOLDER_SPACE);
                firstWord = arr[0];

            }
            else {
                firstWord = Input;
            }
            return firstWord;
        }

    /**
     * @param Input from the scanner
     * @return the String Attributes, which equals the Attributes from the input (f.e. 00002:Alice:Spam:200)
     */
    public static String getAttributes(String Input) {
            if (Input.contains(PLACEHOLDER_SPACE)) {
                String[] arr = Input.split(PLACEHOLDER_SPACE);
                Attributes = arr[1];
            }
            else {
               Attributes = "";

            }
            return Attributes;
        }


    /**
     * Switch with the usage to read in the commands and to execute associated commands
     */
        public Input() { }
    public static void executeCommands(String Input) {
        String firstWord = getCommand(Input);
        String Attributes = getAttributes(Input);
                switch (firstWord) {
                    case (ADD_SONG_TO_PLAYLIST):
                        List.addLast(new Song(Attributes));
                        List.writeList(getPriorityList(new Song(Attributes)));
                        break;
                    case (REMOVE_SONG_FROM_PLAYLIST):
                        removeCommand(Attributes);
                        break;
                    case (PLAY_SONG_FROM_PLAYLIST):
                        playSong(Integer.parseInt(Attributes));
                        List.writeList(createPlaylist());
                        System.out.println(PLAY_SONG_FROM_PLAYLIST);
                        break;
                    case (SKIP_SONG):
                        skipSong();
                        System.out.println(SKIP_SONG);
                        break;
                    case (PEEK_NEXT_SONG_FROM_PLAYLIST):
                        peek();
                        System.out.println(PEEK_NEXT_SONG_FROM_PLAYLIST);
                        break;
                    case (HISTORY_OF_THE_PLAYLIST):
                        writeModifiedList(history);
                        System.out.println(HISTORY_OF_THE_PLAYLIST);
                        break;
                    case (LIST_CURRENT_PLAYLIST):
                        List.writeList(createPlaylist());
                        break;
                    default:
                        break;
                }
            }
        }




