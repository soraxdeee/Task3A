public class Cell {
    private String content;
    private Cell next;

    Cell(String content, Cell next) {
        this.content = content;
        this.next = next;
    }
//+getter fuer content und next

    private Cell head;

    public Cell() {
        this.head = null;


    }
}

// ... list methods
