/**
 * @version 1.0
 * @author ujqgi;
 */
public class Song {
        public int identifier;
        public int priority;
        public int lengthOfSong;
        public int time;
        public String songTitle;
        public String songArtist;

    /**
     * To create the Attribute lengthOfSong
     * @param prev previous song, which length
     * @param lengthOfSong the length of the Song
     */

        Song(ListElement prev, int lengthOfSong) {
               this.identifier = prev.song.identifier;
               this.songArtist = prev.song.songArtist;
               this.songTitle = prev.song.songTitle;
               this.lengthOfSong = lengthOfSong;
               this.priority = prev.song.priority;
               this.time = prev.song.lengthOfSong;
        }

    /**
     * to create a new song
     * @param song  object song with its characteristics
     */
    Song(String song)
        {
            String[] arr = song.split(List.PLACEHOLDER_COLON);
            this.identifier = Integer.parseInt(arr[0]);
            this.songArtist = arr[1];
            this.songTitle = arr[2];
            this.lengthOfSong = Integer.parseInt(arr[3]);
            this.time = Integer.parseInt(arr[3]);
            this.priority = Integer.parseInt(arr[4]);
        }

    /**
     * to convert the object "song" to a string
     * @return converted String
     */
    public String toString()
        {
            String songString = String.format("%05d", identifier);
            songString += ":";
            songString += songArtist;
            songString += ":";
            songString += songTitle;
            songString += ":";
            songString += Integer.toString(lengthOfSong);
            return songString;
        }

    /**
     * same usage toString(), but different in its output (lengthOfSong replaced by time
     * @return
     */
    public String toStringWithTime()
        {
            String songString = String.format("%05d", identifier);
            songString += ":";
            songString += songArtist;
            songString += ":";
            songString += songTitle;
            songString += ":";
            songString += Integer.toString(time);
            return songString;
        }

    }
