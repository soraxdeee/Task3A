/**
 * @version 1.0
 * @author ujqgi;
 */
import java.util.Scanner;
public class Main extends Input {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        while (!input.equals(Input.QUIT_CURRENT_PLAYLIST)) {
            executeCommands(input);
            input = scanner.nextLine();
        }
    }
}
