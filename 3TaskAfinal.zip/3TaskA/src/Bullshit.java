public class Bullshit {
    /*
        int intValue = 125;

        String s = String.format("%05d", IDirgendwas); //muss noch in Int umgeformt werden
        System.out.println(s);
    }
}
-----------------
public static ListElement addAList(ListElement PriorityList1, ListElement PriorityList){
        ListElement Actual = new ListElement((Song)null);
        ListElement priorityList = PriorityList.nextElem;
        while(priorityList != null){
            ListElement newElm = new ListElement(priorityList.getSong());
            Actual.setNextElem(newElm);
            System.out.println("Actual");
            priorityList = PriorityList.nextElem;
        }
        priorityList = PriorityList1.nextElem;
        while(priorityList != null){
            ListElement newElm = new ListElement(priorityList.getSong());
            System.out.println(Actual);
            Actual.setNextElem(newElm);
            priorityList = PriorityList.nextElem;
        }
        return getFirstElem(Actual);


     */
    /*public void FindPosition() {
        int zaehler = 0;
        for (Song song : playList) {
            if (playList.contains(song.priority)) {
                System.out.println(zaehler);
                break;
            }
            else{
                zaehler++;
                continue;
            }
        }



------------
		String s = "Ich bin klug";
		String[] arr = s.split(" ");
		System.out.println(Arrays.toString(arr));
		------------------------
		  PLACEHOLDER_ID = Integer.parseInt(Info[0]);
                    PLACEHOLDER_ARTIST = Info[1];
                    PLACEHOLDER_TITLE = Info[2];
                    PLACEHOLDER_LENGTH = Integer.parseInt(Info[3]);
                    PLACEHOLDER_PRIORITY = Integer.parseInt(Info[4]);
                    ------------------------------------------
        add
        String Information = arr[1]; //beide Zeilen später in Methode zusammenfassen!!!
                    String[] Info = Information.split(PLACEHOLDER_COLON);
                    playList.add(new Song(Integer.parseInt(Info[0]), Info[1], Info[2], Integer.parseInt(Info[3]), Integer.parseInt(Info[4])));
                    Comparator<Song> DESCENDING_COMPARATOR = Comparator.comparingInt((priority) -> priority.priority);
                    playList.sort(DESCENDING_COMPARATOR);


                     /* public void AddSongToPlaylist(){
        playList.add(new Song(Integer.parseInt(Info[0]), Info[1], Info[2], Integer.parseInt(Info[3]), Integer.parseInt(Info[4])));
        Comparator<Song> DESCENDING_COMPARATOR = Comparator.comparingInt((priority) -> priority.priority);
        playList.sort(DESCENDING_COMPARATOR);
    }

    */
    // Sorts the array list using comparator
}

   /* public void SortPlayList(){
        Collections.sort(playList, priority);
    }
    ------------------------------------------------
     /*
        do {
            String input = scanner.nextLine();
            executeCommands(input);
        } while (!executeCommands(input).equals(QUIT_CURRENT_PLAYLIST));


------------------------------------
 /*
    private static int PLACEHOLDER_AMOUNT;
    private static int PLACEHOLDER_ID; //5 Stellen? -> siehe playlist
    private static int  PLACEHOLDER_TIME;
    private static int  PLACEHOLDER_LENGTH;
    private static int PLACEHOLDER_PRIORITY; //??
    private static String PLACEHOLDER_ARTIST;
    private static String PLACEHOLDER_TITLE;
    ------------------------------------------
    public static final String PLACEHOLDER_SPACE = " ";
    public static final String PLACEHOLDER_COLON = ":";
    //private static final int [] PLACEHOLDER_PRIORITY = new int[6]; //??
    private static final String ADD_SONG_TO_PLAYLIST = "add";
    private static final String REMOVE_SONG_FROM_PLAYLIST = "remove";
    private static final String PLAY_SONG_FROM_PLAYLIST = "play";
    private static final String SKIP_SONG = "skip";
    private static final String PEEK_NEXT_SONG_FROM_PLAYLIST = "peek";
    private static final String LIST_CURRENT_PLAYLIST = "list";
    private static final String HISTORY_OF_THE_PLAYLIST = "history";
    ---------------------------------------------------------------
    public class List {
    /*String SongId = "d";
    Cell head;
    //leere Liste wird erzeugt
    public List(){
        head = null;
    }
    public static void addSong (String input){
        Cell cell = new Cell(input, null);
    }

     */
   /* Priority.PRIORITY zero = Priority.PRIORITY.PRIORITY_ZERO;
    Priority.PRIORITY one = Priority.PRIORITY.PRIORITY_ONE;
    Priority.PRIORITY two = Priority.PRIORITY.PRIORITY_TWO;
    Priority.PRIORITY three = Priority.PRIORITY.PRIORITY_THREE;
    Priority.PRIORITY four = Priority.PRIORITY.PRIORITY_FOUR;
    Priority.PRIORITY five = Priority.PRIORITY.PRIORITY_FIVE;

    ---------------------------------------------------------------------------------------------
   static ListElement startElem = new ListElement("Head");
    public List() {
    }
    public static void createPriorityLists(){
        ListElement Priority_Zero = new ListElement("Head");
        ListElement Priority_One = new ListElement("Head");
        ListElement Priority_Two = new ListElement("Head");
        ListElement Priority_Three = new ListElement("Head");
        ListElement Priority_Four = new ListElement("Head");
        ListElement Priority_Five = new ListElement("Head");
    }
    public static void addLast(Object Song) {
        ListElement newElem = new ListElement(Song);
        ListElement lastElem = getLastElem();
        lastElem.setNextElem(newElem);

    }


    public static void insertAfter(Object prevItem, Object newItem) {
        ListElement newElem, nextElem, pointerElem;
        pointerElem = startElem.getNextElem();
        while(pointerElem != null && !pointerElem.getObj().equals(prevItem)){
            pointerElem = pointerElem.getNextElem();
        }
        newElem = new ListElement(newItem);
        nextElem = pointerElem.getNextElem();
        pointerElem.setNextElem(newElem);
        newElem.setNextElem(nextElem);
    }

    public static void delete(Object Song){
        ListElement le = startElem;
        while (le.getNextElem() != null && !le.getObj().equals(Song)){
            if(le.getNextElem().getObj().equals(Song)){
                if(le.getNextElem().getNextElem()!=null)
                    le.setNextElem(le.getNextElem().getNextElem());
                else{
                    le.setNextElem(null);
                    break;
                }
            }
            le = le.getNextElem();
        }
    }

    public static boolean find(Object Song){
        ListElement le = startElem;
        while (le != null){
            if(le.getObj().equals(Song))
                return true;
            le = le.nextElem;
        }
        return false;
    }

    public ListElement getFirstElem() {
        return startElem;
    }

    public static ListElement getLastElem() {
        ListElement le = startElem;
        while(le.getNextElem() != null){
            le = le.getNextElem();
        }
        return le;
    }

    public static void writeList() {
        ListElement le = startElem;
        while(le != null){
            System.out.println(le.getObj());
            le = le.getNextElem();
        }
    }

}

--------------------
public class EinfachVerketteteListe {

        ListElement startElem = new ListElement("Kopf");

        public EinfachVerketteteListe() {}

        public void addLast(Object Song){
            ListElement newElem = new ListElement(Song);
            ListElement lastElem = getLastElem();
            lastElem.setNextElem(newElem);
        }

        public void insertAfter(Object prevItem, Object newItem) {
            ListElement newElem, nextElem, pointerElem;
            pointerElem = startElem.getNextElem();
            while(pointerElem != null && !pointerElem.getObj().equals(prevItem)){
                pointerElem = pointerElem.getNextElem();
            }
            newElem = new ListElement(newItem);
            nextElem = pointerElem.getNextElem();
            pointerElem.setNextElem(newElem);
            newElem.setNextElem(nextElem);
        }

        public void delete(Object Song){
            ListElement le = startElem;
            while (le.getNextElem() != null && !le.getObj().equals(Song)){
                if(le.getNextElem().getObj().equals(Song)){
                    if(le.getNextElem().getNextElem()!=null)
                        le.setNextElem(le.getNextElem().getNextElem());
                    else{
                        le.setNextElem(null);
                        break;
                    }
                }
                le = le.getNextElem();
            }
        }

        public boolean find(Object Song){
            ListElement le = startElem;
            while (le != null){
                if(le.getObj().equals(Song))
                    return true;
                le = le.nextElem;
            }
            return false;
        }

        public ListElement getFirstElem() {
            return startElem;
        }

        public ListElement getLastElem() {
            ListElement le = startElem;
            while(le.getNextElem() != null){
                le = le.getNextElem();
            }
            return le;
        }

        public void writeList() {
            ListElement le = startElem;
            while(le != null){
                System.out.println(le.getObj());
                le = le.getNextElem();
            }
        }
    }

    */

// Sorts the array list using comparator


