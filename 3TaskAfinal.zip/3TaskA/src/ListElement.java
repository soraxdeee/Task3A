/**
 * @version 1.0
 * @author ujqgi;
 */
public class ListElement {
    Song song;

    ListElement nextElem;

    /**
     * creates a new List Element
     * @param song
     */
    public ListElement(Song song) {
        this.song = song;
        nextElem = null;
    }

    public void setNextElem(ListElement nextElem) {
        this.nextElem = nextElem;
    }

    public ListElement getNextElem() {
        return nextElem;
    }

    public Song getSong() {
        return song;
    }
}
