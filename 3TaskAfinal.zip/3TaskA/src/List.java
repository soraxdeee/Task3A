/**
 * @version 1.0
 * @author ujqgi;
 */
public class List {

    public List() {
    }

    public static final String PLACEHOLDER_COLON = ":";
    static ListElement Priority_Zero = new ListElement(null);
    static ListElement Priority_One = new ListElement(null);
    static ListElement Priority_Two = new ListElement(null);
    static ListElement Priority_Three = new ListElement(null);
    static ListElement Priority_Four = new ListElement(null);
    static ListElement Priority_Five = new ListElement(null);
    static ListElement history = new ListElement(null);
    private static ListElement songRelatedList;

    /**
     * method to simulate playing a song
     * @param length equals the running time of the song (f.e. if length < songLenght -> song is "paused"
     * @returns the revised list
     */
    public static ListElement playSong(int length) {
        ListElement prev = new ListElement(null);
        ListElement newElem = new ListElement(null);
while (length != 0) {       //checks which of the PriorityList contains the song with highest priority
    if (Priority_Zero.nextElem != null) {
        newElem = Priority_Zero;
    } else if (Priority_One.nextElem != null) {
        newElem = Priority_One;
    } else if (Priority_Two.nextElem != null) {
        newElem = Priority_Two;
    } else if (Priority_Three.nextElem != null) {
        newElem = Priority_Three;
    } else if (Priority_Four.nextElem != null) {
        newElem = Priority_Four;
    } else if (Priority_Five.nextElem != null) {
        newElem = Priority_Five;
    }
    while (newElem.nextElem != null) {
        if (length == newElem.nextElem.song.lengthOfSong) { //checks if length equals length of the song with the highest priority
            createHistory(newElem);
            removeFirstSong(getPriorityList(newElem.nextElem.getSong()));
            length = 0;
            break;

        } else if (length < newElem.nextElem.song.lengthOfSong) {
            prev.setNextElem(new ListElement(new Song(newElem.nextElem, newElem.nextElem.song.lengthOfSong - length)));
            prev.nextElem.setNextElem(newElem.nextElem.nextElem);
            newElem.setNextElem(prev.nextElem);
            length = 0;
            break;
        } else {
            length = length - newElem.nextElem.song.lengthOfSong;
            createHistory(newElem);
            removeFirstSong(getPriorityList(newElem.nextElem.getSong()));
        }
    }
    }   return newElem;
    }

    /**
     * method to create the history (from the history command)
     * @param newElem is equal to played songs
     */
    public static void createHistory(ListElement newElem) {
        ListElement place = getLastElem(history);
        place.setNextElem(new ListElement(newElem.nextElem.getSong()));
    }

    /**
     * method peek(), to get the next song in the playlist
     */
    public static void peek() {
        ListElement peek = createPlaylist().nextElem;
        System.out.println(peek.song.identifier + ":" + peek.song.songArtist + ":" + peek.song.songTitle
                + ":" + peek.song.time + ":" + peek.song.lengthOfSong);
    }

    /**
     * method skipSong(), to skip the next song (with "highest" priority) from the playlist
     */
    public static void skipSong() {
        removeFirstSong(getPriorityList(createPlaylist().nextElem.getSong()));
    }

    /**
     * creates a Playlist, by attaching the PriorityLists
     * @returns the Playlist
     */
    public static ListElement createPlaylist() {
        ListElement playlist = new ListElement(null);
        ListElement zero = Priority_Zero.nextElem;
        while (zero != null) //checks if the PriorityList is empty
        {
            getLastElem(playlist).nextElem = new ListElement(zero.song);
            zero = zero.nextElem; //copys the current PriorityList to the end of the playlist
        }

        ListElement one = Priority_One.nextElem;
        while (one != null)
        {
            getLastElem(playlist).nextElem = new ListElement(one.song);
            one = one.nextElem;
        }
        ListElement two = Priority_Two.nextElem;
        while (two != null)
        {
            getLastElem(playlist).nextElem = new ListElement(two.song);
            two = two.nextElem;
        }
        ListElement three = Priority_Three.nextElem;
        while(three != null)
        {
            getLastElem(playlist).nextElem = new ListElement(three.song);
            three = three.nextElem;
        }
        ListElement four = Priority_Four.nextElem;
        while (four != null)
        {
            getLastElem(playlist).nextElem = new ListElement(four.song);
            four = four.nextElem;
        }
        ListElement five = Priority_Five.nextElem;
        while (five != null)
        {
            getLastElem(playlist).nextElem = new ListElement(five.song);
            five = five.nextElem;
        }
        return playlist;
    }


    /**
     *
     * @param song is the song to be sorted
     * @return the appropriated PriorityList for the entered song
     */
    public static ListElement getPriorityList(Song song) {
        switch(song.priority) {
            case(0):
                 songRelatedList =  Priority_Zero;
                break;
            case(1):
                 songRelatedList =  Priority_One;
                break;
            case(2):
                 songRelatedList =  Priority_Two;
                break;
            case(3):
                 songRelatedList =  Priority_Three;
                break;
            case(4):
                songRelatedList =  Priority_Four;
                break;
            case(5):
                 songRelatedList =  Priority_Five;
                break;
        }
        return songRelatedList;

    }

    /**
     * method addLast() adds a Song to the end of a List
     * @param song the song to be added
     */
    public static void addLast(Song song) {
         ListElement newElem = new ListElement(song);
         ListElement lastElem = getLastElem(getPriorityList(song));
        lastElem.setNextElem(newElem);

    }

    /**
     * removes the first Element != null(which is a song) from a list
     * @param list to be revised
     * @return the new list (without the ListElement removed)
     */
    public static ListElement removeFirstSong(ListElement list) {
        ListElement le = list.nextElem;
        ListElement prev = list;

                prev.setNextElem(le.getNextElem());
        return list;
            }

    /**
     * removes Song with special identity
     * @param Attributes to read out the identity
     */
    public static void removeCommand(String Attributes) {
        int a = getLengthOfList(Priority_Zero);
        Priority_Zero = removeSong(Attributes, Priority_Zero);
        int i = a - getLengthOfList(Priority_Zero);
        a = getLengthOfList(Priority_One);
        Priority_One = removeSong(Attributes, Priority_One);
        i = a - getLengthOfList(Priority_One) + i;
        a = getLengthOfList(Priority_Two);
        Priority_Two = removeSong(Attributes, Priority_Two);
        i = a - getLengthOfList(Priority_Two) + i;
        a = getLengthOfList(Priority_Three);
        Priority_Three = removeSong(Attributes, Priority_Three);
        i = a - getLengthOfList(Priority_Three) + i;
        a = getLengthOfList(Priority_Four);
        Priority_Four = removeSong(Attributes, Priority_Four);
        i = a - getLengthOfList(Priority_Four) + i;
        a = getLengthOfList(Priority_Five);
        Priority_Five = removeSong(Attributes, Priority_Five);
        i = a - getLengthOfList(Priority_Five) + i;
        System.out.println("Removed " + i);
    }

    /**
     * gets the Length of a list
     * @param list to be checked
     * @returns the counter (length)
     */
    public static int getLengthOfList(ListElement list) {
    ListElement le = list.nextElem;
    int counter = 0;
        while (le != null) {
            counter++;
            le = le.nextElem;
        }
        return counter;
}

    /**
     * removes a Song
     * @param identity which identifies the song that has to be removed
     * @param list from which the song has to be removed
     * @returns the list without the removed song
     */
    public static ListElement removeSong(String identity, ListElement list) {
        ListElement le = list.nextElem;
        ListElement prev = list;

        while (le != null) {
            int id = Integer.valueOf(identity);

            if (id == le.song.identifier) {
                prev.setNextElem(le.getNextElem());
                le = le.getNextElem();
                continue;
            }
            prev = le;
            le = le.getNextElem();
        }

        return list;
    }

    /**
     * gets the last Element of a list
     * @param list from which the last Element needed
     * @returns the last Element of the list
     */
    public static ListElement getLastElem(ListElement list) {
        ListElement le = list;
        while (le.getNextElem() != null) {
            le = le.getNextElem();
        }
        return le;
    }

    /**
     * method to print out a list
     * @param list which has to be printed out
     */
    public static void writeList(ListElement list) {
        ListElement le = list.nextElem;
        while (le != null) {
            System.out.println(le.getSong().toString());
            le = le.getNextElem();
        }
    }

    /**
     * method to print out a list (with special Attributes)
     * @param list which has to be printed out
     */
    public static void writeModifiedList(ListElement list) {
        ListElement le = list.nextElem;
        while (le != null) {
            System.out.println(le.getSong().toStringWithTime());
            le = le.getNextElem();
        }
    }



    }

